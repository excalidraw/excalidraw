# @excalidraw/element

## Install

```bash
npm install @excalidraw/element
```

If you prefer Yarn over npm, use this command to install the Excalidraw utils package:

```bash
yarn add @excalidraw/element
```

With PNPM, similarly install the package with this command:

```bash
pnpm add @excalidraw/element
```
