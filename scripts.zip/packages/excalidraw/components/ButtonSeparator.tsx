export const ButtonSeparator = () => (
  <div
    style={{
      width: 1,
      height: "1rem",
      backgroundColor: "var(--default-border-color)",
      margin: "0 auto",
    }}
  />
);
